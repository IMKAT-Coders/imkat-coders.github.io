# IMKAT.CSS
Hello! So I, Ishan Kuber, along with my friend Arin Torney have made this project as a 
CSS Framework which we wanted to use for our most of the projects. And also we want to
share it with others, so that we might not be the only ones using such a framework which 
we made with so much effort! And we really want others to use this.
That is why I am sharing this on Github. I hope you like it!

Thank you!

P.S: This framework is still 'Work in Progress'. We will soon complete it, but still its
also good as it is now.
